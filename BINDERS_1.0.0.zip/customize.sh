#!/system/bin/sh
# Original Author : Diyusa
# Version : 1.0.0 
SKIPMOUNT=false
LATESTARTSERVICE=true

MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
VERSION=$(getprop ro.build.version.release)
K_VER=$(uname -r)
ui_print "---------------------------------------"
ui_print "   B  I  N  D  E  R  S "
ui_print "-----------------------------------------"
ui_print " • DEVICE  : $MODEL [$DEVICE]"
ui_print " • ANDROID : $VERSION"
ui_print " • KERNEL  : $K_VER"
ui_print " • AUTHOR  : DIYUSA"
ui_print "-----------------------------------------"
ui_print " • PUBLISHER : NO ONE " #YOU CAN EDIT HERE
ui_print "-----------------------------------------"
ui_print "   B  I  N  D  E  R  S"
ui_print "-----------------------------------------"
ui_print " • IF THERE IS SOMETHING SPECIAL HERE "
ui_print " • MAYBE THAT'S YOU "
ui_print " -----------------------------------------"
ui_print " • DON'T BE A THIEF, BE A REAL DEVELOPER "
ui_print " • RESPECT THE ORIGINAL WORK!            "
ui_print "-----------------------------------------"
sleep 1
ui_print "- Extracting core binaries..."
unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >&2

sleep 1
ui_print "- Locking permissions..."
set_perm_recursive "$MODPATH" 0 0 0755 0644
if [ -f "$MODPATH/service.sh" ]; then
    set_perm "$MODPATH/service.sh" 0 0 0755
    sed -i 's/\r$//' "$MODPATH/service.sh"
fi

sleep 1
ui_print "---------------------------------------"
ui_print " BINDER HAS BEEN INSTALLED "
ui_print "---------------------------------------"

exit 0