#!/system/bin/sh
# Refined by Diyusa 
(
    until [ "$(getprop sys.boot_completed)" = "1" ]; do 
        sleep 30
    done

    sleep 5
    
    GHOST_DIR="/dev/rn_binder"
    mkdir -p "$GHOST_DIR"
    mount -t tmpfs -o mode=0755,size=1M tmpfs "$GHOST_DIR"
    
    ghost_strike() {
        VAL="$1"
        TARGET="$2"
        NAME=$(echo "$TARGET" | sed 's/\//_/g')
        
        if [ -f "$TARGET" ]; then
            umount -l "$TARGET" 2>/dev/null
            
            chmod 644 "$TARGET" 2>/dev/null
            echo "$VAL" > "$GHOST_DIR/$NAME"
            chmod 644 "$GHOST_DIR/$NAME"
            
            mount --bind "$GHOST_DIR/$NAME" "$TARGET"
            chmod 444 "$TARGET" 2>/dev/null
            mount -o remount,ro,bind "$TARGET" 2>/dev/null
        fi
    }
    PID_SF=$(pidof surfaceflinger)
    if [ ! -z "$PID_SF" ]; then
        chrt -f -p 99 "$PID_SF" 2>/dev/null
        renice -n -20 -p "$PID_SF" 2>/dev/null
    fi
       
    # --- BiNDERS PROPS ---
    service call SurfaceFlinger 1008 i32 1
    resetprop -n debug.sf.disable_backpressure 1
    resetprop -n debug.sf.enable_gl_backpressure 0
    resetprop -n debug.sf.latch_unsignaled 1
    resetprop -n vendor.powerhal.adpf.index 0
    resetprop -n dalvik.vm.heapgrowthlimit 256m
    resetprop -n dalvik.vm.heapsize 512m
    resetprop -n dalvik.vm.heaptargetutilization 0.75
    resetprop -n dalvik.vm.heapstartsize 16m
    resetprop -n renderthread.priority 1
    resetprop -n windowsmgr.max_events_per_sec 300
    resetprop -n persist.vendor.qti.input_optimize true
    resetprop -n ro.min.fling_velocity 60000
    resetprop -n ro.max.fling_velocity 120000
    resetprop -n view.scroll_friction 0.0
    resetprop -n ro.hwui.disable_scissoring true
    resetprop -n ro.hwui.disable_scissoring true
    resetprop -n ro.hwui.texture_cache_size 88
    resetprop -n ro.surface_flinger.set_touch_timer_ms 0
    resetprop -n ro.surface_flinger.set_idle_timer_ms 0
    resetprop -n ro.surface_flinger.set_display_menu_timer_ms 0
    resetprop -n debug.sf.hw 1
    resetprop -n persist.sys.ui.hw true
    resetprop -n ro.surface_flinger.max_frame_buffer_acquired_buffers 3
    resetprop -n debug.sf.enable_egl_image_tracker 1
    resetprop -n debug.sf.disable_client_composition_cache 0
    resetprop -n debug.sf.predict_hwc_composition_strategy 1  
    
    # Surface Flinger [SF] If Lagging, You Can Delete the SF Rows Below
    resetprop -n debug.sf.early_phase_offset_ns 500000
    resetprop -n debug.sf.early_gl_phase_offset_ns 3000000
    resetprop -n debug.sf.high_fps_early_phase_offset_ns 6100000
    resetprop -n debug.sf.high_fps_early_gl_phase_offset_ns 9000000
        
    # MEMORY
    ghost_strike "madvise" /sys/kernel/mm/transparent_hugepage/enabled
    ghost_strike "defer+madvise" /sys/kernel/mm/transparent_hugepage/defrag
    ghost_strike "0" /sys/kernel/mm/transparent_hugepage/khugepaged/defrag
    
    # CPU Policy Boost
    if [ -d /sys/devices/system/cpu/cpufreq/policy4/walt ]; then
        ghost_strike "1" /sys/devices/system/cpu/cpufreq/policy0/walt/boost
        ghost_strike "1" /sys/devices/system/cpu/cpufreq/policy4/walt/boost
    fi

    # UCLAMP & Sched
    if [ -d /dev/cpuctl/top-app ]; then
        ghost_strike "20.00" /dev/cpuctl/top-app/cpu.uclamp.min
        ghost_strike "1" /dev/cpuctl/top-app/cpu.uclamp.latency_sensitive
        ghost_strike "1" /proc/sys/kernel/sched_child_runs_first
        ghost_strike "2" /proc/sys/kernel/sched_rr_timeslice_ms
        ghost_strike "0" /proc/sys/kernel/sched_schedstats
        [ -f /proc/sys/kernel/sched_pelt_multiplier ] && ghost_strike "1" /proc/sys/kernel/sched_pelt_multiplier
    fi

    # GPU
    ghost_strike "1" /sys/class/kgsl/kgsl-3d0/force_no_nap
    ghost_strike "1" /sys/class/kgsl/kgsl-3d0/force_clk_on
    ghost_strike "10000" /sys/class/kgsl/kgsl-3d0/idle_timer
    
    # BINDER
    ghost_strike "1" /sys/module/binder/parameters/debug_mask
    ghost_strike "1" /sys/module/binder/parameters/stop_on_user_error
    
    # VM TWEAKS
    ghost_strike "0" /proc/sys/vm/page-cluster
    ghost_strike "50" /proc/sys/vm/vfs_cache_pressure
    ghost_strike "15" /proc/sys/vm/dirty_ratio
    ghost_strike "5" /proc/sys/vm/dirty_background_ratio
    ghost_strike "1" /proc/sys/vm/compact_unevictable_allowed

    # TOUCH FTS
    for fts_path in /sys/devices/platform/soc/*.qcom,qupv3_0_geni_se/*.i2c/i2c-*/1-0038/; do
        [ -d "$fts_path" ] || continue
        ghost_strike "1" "${fts_path}fts_hw_reset"
        ghost_strike "0" "${fts_path}fts_gesture_mode"
        ghost_strike "1" "${fts_path}fts_glove_mode"
        ghost_strike "1" "${fts_path}fts_charger_mode"
        ghost_strike "1" "${fts_path}fts_ta_mode"
        ghost_strike "0" "${fts_path}fts_edge_mode"
        ghost_strike "1" "${fts_path}fts_irq"
    done

    # I/O SCHEDULER
    for block in /sys/block/sd*/queue/; do
        [ -d "$block" ] || continue
        ghost_strike "mq-deadline" "${block}scheduler"
        ghost_strike "128" "${block}read_ahead_kb"
        ghost_strike "256" "${block}nr_requests"
        ghost_strike "0" "${block}iostats"
        ghost_strike "0" "${block}add_random"
    done

    # LOGGING
    ghost_strike "0" /proc/sys/kernel/printk_devkmsg
    ghost_strike "0" /sys/kernel/tracing/tracing_on
    ghost_strike "0 0 0 0" /proc/sys/kernel/printk
# Diyusa
    echo "BiNDERS Full Deployment | $(date)" > /data/local/tmp/binders.log
) &

#Diyusa
